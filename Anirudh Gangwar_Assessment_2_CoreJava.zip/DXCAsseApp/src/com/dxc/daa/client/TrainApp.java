package com.dxc.daa.client;
import com.dxc.daa.dbcon.*;
import com.dxc.daa.model.Train;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.dxc.daa.dao.*;

@SuppressWarnings("unused")
public class TrainApp {
	int choice=0;
	@SuppressWarnings("resource")
	public void launchTrainApp() {
		// TODO Auto-generated method stub
			UserDAO userDAO=new UserDAOImpl();
			TrainDAO trainDAO = new TrainDAOImpl();
			Scanner sc=new Scanner(System.in);
			System.out.println("Username: ");
			String username=sc.next();
			System.out.println("Password: ");
			String password=sc.next();
			if(userDAO.validate(username,password)){
				System.out.println("Access Granted");
				while (true) {
					System.out.println("M E N U ");
					System.out.println("1. Display all training records : ");
					System.out.println("2. Display Records one by one and update the percentage : ");
					System.out.println("3. E X I T : ");
					
					System.out.println("Please enter your choice : (1-3)");
					choice = sc.nextInt();
					switch (choice) {
					case 1:
						System.out.println(trainDAO.getAllRecords());
						break;
					case 2:
						List<Train> record=new ArrayList<Train>();
						record=trainDAO.getAllRecords();
						Iterator<Train> iterator=record.iterator();
						
						while(iterator.hasNext()) {
							Train train=new Train();
							train=iterator.next();
							System.out.println(train.toString());
							if(train.getPercentage()==0) {
								System.out.println("Enter percentage: ");
								int percentage=sc.nextInt();
								trainDAO.updatePercentage(train.getSapId(),percentage);
							}
							else {
								System.out.println("Percentage already exists");
							}
						}
						
						break;
					case 3:
						System.out.println("Thanks for using my app");
						System.exit(0);
						break;
					default:
						System.out.println(" Please enter (1-3)");
				}
			}
			}
			else {
				System.out.println("Invalid credentials");
				System.exit(0);
			}
		}
	}

