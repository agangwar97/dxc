package com.dxc.daa.client;
import com.dxc.daa.dbcon.*;

@SuppressWarnings("unused")
public class Main {

	public static void main(String[] args) {
		System.out.println("###Training Assessment APP###");
		TrainApp app = new TrainApp();
		app.launchTrainApp();
	}
}
