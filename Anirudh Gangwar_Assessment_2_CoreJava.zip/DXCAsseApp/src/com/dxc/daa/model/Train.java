package com.dxc.daa.model;

public class Train {
	private int SapId;
	private String EmpName;
	private String Stream;
	private int percentage;
	public Train() {
		// TODO Auto-generated constructor stub
	}
	public Train(int sapId, String empName, String stream, int percentage) {
		super();
		SapId = sapId;
		EmpName = empName;
		Stream = stream;
		this.percentage = percentage;
	}
	@Override
	public String toString() {
		return "Train [SapId=" + SapId + ", EmpName=" + EmpName + 
				", Stream=" + Stream + ", percentage=" + percentage+ "]";
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((EmpName == null) ? 0 : EmpName.hashCode());
		result = prime * result + SapId;
		result = prime * result + ((Stream == null) ? 0 : Stream.hashCode());
		result = prime * result + percentage;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Train other = (Train) obj;
		if (EmpName == null) {
			if (other.EmpName != null)
				return false;
		} else if (!EmpName.equals(other.EmpName))
			return false;
		if (SapId != other.SapId)
			return false;
		if (Stream == null) {
			if (other.Stream != null)
				return false;
		} else if (!Stream.equals(other.Stream))
			return false;
		if (percentage != other.percentage)
			return false;
		return true;
	}
	public int getSapId() {
		return SapId;
	}
	public void setSapId(int sapId) {
		SapId = sapId;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public String getStream() {
		return Stream;
	}
	public void setStream(String stream) {
		Stream = stream;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	
}
