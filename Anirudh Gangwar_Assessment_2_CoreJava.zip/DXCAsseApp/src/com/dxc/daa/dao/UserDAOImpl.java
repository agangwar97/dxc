package com.dxc.daa.dao;

import com.dxc.daa.dbcon.*;
import com.dxc.daa.model.User;
import java.sql.*;

@SuppressWarnings("unused")
public class UserDAOImpl implements UserDAO{
	
	Connection connection = (Connection) DBConnection.getConnection();
	private static final String FETCH_USER_DETAILS = "select * from users where username=? AND password=?";
	private static final String FETCH_TRAIN_RECORDS = "select * from training";
	public UserDAOImpl(){
	}
	
	@Override
	public boolean validate(String username, String password) {
		// TODO Auto-generated method stub
		boolean exist=false;
		try {
			PreparedStatement statement=connection.prepareStatement(FETCH_USER_DETAILS);
			statement.setString(1,username);
			statement.setString(2,password);
			ResultSet res=statement.executeQuery();
			
			if(res.next()) {
				exist=true;
			}
			else {
				exist=false;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		return exist;
	
	}

}
