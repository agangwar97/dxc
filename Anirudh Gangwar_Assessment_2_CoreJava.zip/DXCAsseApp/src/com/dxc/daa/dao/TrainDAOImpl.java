package com.dxc.daa.dao;

import com.dxc.daa.dbcon.*;
import com.dxc.daa.model.Train;
import com.dxc.daa.model.User;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@SuppressWarnings("unused")
public class TrainDAOImpl implements TrainDAO{
	
	Connection connection = (Connection) DBConnection.getConnection();
	private static final String FETCH_TRAIN_RECORDS = "select * from training";
	public TrainDAOImpl(){
	}
	
	public List<Train> getAllRecords() {
		// TODO Auto-generated method stub
		List<Train> allRecords = new ArrayList<Train>();
		try {
			Statement stat = connection.createStatement();
			ResultSet res = stat.executeQuery(FETCH_TRAIN_RECORDS);
			while(res.next()) {
				Train train=new Train();
				train.setSapId(res.getInt(1));
				train.setEmpName(res.getString(2));
				train.setStream(res.getString(3));
				train.setPercentage(res.getInt(4));
				allRecords.add(train);
			}
			}catch (SQLException e) {
				e.printStackTrace();
		}
		return allRecords;
	}
	public void updatePercentage(int sapId,int percentage) {
		try {
			PreparedStatement preparedStatement=connection.prepareStatement("update training set percentage=? where sapId=?");
			preparedStatement.setInt(1,percentage);
			preparedStatement.setInt(2,sapId);
			preparedStatement.executeUpdate();
		}catch (SQLException e) {
			e.printStackTrace();
	}
}
}