package com.dxc.daa.dao;
import java.util.List;

import com.dxc.daa.dbcon.*;
import com.dxc.daa.model.Train;

@SuppressWarnings("unused")
public interface TrainDAO {
	
	public List<Train> getAllRecords();
	public void updatePercentage(int sapId, int percentage);
}
