package com.dxc.daa.dao;
import com.dxc.daa.dbcon.*;

@SuppressWarnings("unused")
public interface UserDAO {
	
	public boolean validate(String username,String password);
}
