package com.dxc.model;

import java.util.Set;

import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.search.annotations.IndexedEmbedded;

@Entity
@Table(name="Doctor")
public class Doctor {
	@Id
	private int id;
	private String name;
	private int fees;
	@ElementCollection
	@IndexedEmbedded
	private Set<HospitalDetails>hospitalDetails;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getFees() {
		return fees;
	}
	public void setFees(int fees) {
		this.fees = fees;
	}
	public Set<HospitalDetails> getHospitalDetails() {
		return hospitalDetails;
	}
	public void setHospitalDetails(Set<HospitalDetails> hospitalDetails) {
		this.hospitalDetails = hospitalDetails;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + fees;
		result = prime * result + ((hospitalDetails == null) ? 0 : hospitalDetails.hashCode());
		result = prime * result + id;
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (fees != other.fees)
			return false;
		if (hospitalDetails == null) {
			if (other.hospitalDetails != null)
				return false;
		} else if (!hospitalDetails.equals(other.hospitalDetails))
			return false;
		if (id != other.id)
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Doctor [id=" + id + ", name=" + name + ", fees=" + fees + ", hospitalDetails=" + hospitalDetails + "]";
	}
	public Doctor(int id, String name, int fees, Set<HospitalDetails> hospitalDetails) {
		super();
		this.id = id;
		this.name = name;
		this.fees = fees;
		this.hospitalDetails = hospitalDetails;
	}
	public Doctor() {
		super();
	}


	
}
