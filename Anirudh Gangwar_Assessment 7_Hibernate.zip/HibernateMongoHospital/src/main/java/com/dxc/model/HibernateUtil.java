package com.dxc.model;

import org.hibernate.SessionFactory;
import org.hibernate.ogm.cfg.OgmConfiguration;

public class HibernateUtil {

	public static SessionFactory getSessionFactory() {
		OgmConfiguration configuration =new OgmConfiguration();
		configuration.configure();
		@SuppressWarnings("deprecation")
		SessionFactory factory=configuration.buildSessionFactory();
		return factory;
	}
}
