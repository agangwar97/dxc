package com.dxc.model;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;

public class Client 
{
    public static void main( String[] args )
    {
        SessionFactory factory=HibernateUtil.getSessionFactory();
        Session session=factory.openSession();
        Transaction transaction=session.beginTransaction();
        
        HospitalDetails h1=new HospitalDetails("Medanta", "Gurgaon");

        Set<HospitalDetails> allDetails=new HashSet<HospitalDetails>();
        allDetails.add(h1);
        allDetails.add(new HospitalDetails("Fortis","Delhi"));
        Doctor doctor=new Doctor(213, "Jeevesh", 800, allDetails);
        session.save(doctor);
        transaction.commit();
        System.out.println("Done");
    }
}
