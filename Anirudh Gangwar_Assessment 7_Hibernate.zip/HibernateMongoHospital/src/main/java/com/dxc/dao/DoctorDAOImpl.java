package com.dxc.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dxc.model.Doctor;
import com.dxc.model.HibernateUtil;

public class DoctorDAOImpl implements DoctorDAO {

	SessionFactory sf=HibernateUtil.getSessionFactory();

	public Doctor getDoctor(int id) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Doctor doctor=(Doctor) session.get(Doctor.class,id);
		transaction.commit();
		return doctor;
	}

	@SuppressWarnings("unchecked")
	public List<Doctor> getAllDoctors() {
		Session session=sf.openSession();
		Query query=session.createQuery("from Doctor");
		return query.list();
	}

	public void addDoctor(Doctor doctor) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.save(doctor);
        transaction.commit();
        System.out.println(doctor.getName()+"saved successfully");
        session.close();
	}

	public void deleteDoctor(int id) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		Doctor doctor=new Doctor();
		doctor.setId(id);
		session.delete(doctor);
		transaction.commit();
		System.out.println(" deleted successfully");
        session.close();		
	}

	public void updateDoctor(Doctor doctor) {
		Session session=sf.openSession();
		Transaction transaction=session.beginTransaction();
		session.update(doctor);
		transaction.commit();
		System.out.println(doctor.getName()+" updated successfully");
        session.close();		
	}

	public boolean isDoctorExists(int id) {
		Session session=sf.openSession();
		Doctor doctor = (Doctor) session.get(Doctor.class, id);
		if(doctor==null) {
			session.close();
			return false;}
		else {
			session.close();
			return true;}
	}

	public Doctor searchByName(String name) {
		Session session = sf.openSession();
		Doctor doctor =(Doctor) session.get(Doctor.class, name);
		Transaction transaction=session.beginTransaction();
		transaction.commit();
		session.close();
		return doctor;
	}

}
