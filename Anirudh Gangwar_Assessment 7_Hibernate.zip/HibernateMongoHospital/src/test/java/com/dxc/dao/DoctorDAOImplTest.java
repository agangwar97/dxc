package com.dxc.dao;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.dxc.model.Doctor;
import com.dxc.model.HospitalDetails;

import junit.framework.TestCase;

public class DoctorDAOImplTest extends TestCase {

	DoctorDAOImpl impl;
	@Override
	protected void setUp() throws Exception {
		impl=new DoctorDAOImpl();
	}
	@Override
	protected void tearDown() throws Exception {

		super.tearDown();
	}
	public void testGetDoctor() {
		HospitalDetails details1=new HospitalDetails("Gurgaon", "Arathya");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
		Doctor doctor1=new Doctor(6532,"Vinesh",4500,alldetails);
		impl.addDoctor(doctor1);
		Doctor doctor2=impl.getDoctor(6532);
		assertNotNull(doctor2);	
		}

	public void testGetAllDoctors() {
		List<Doctor> dnames=impl.getAllDoctors();
		System.out.println(dnames);
		assertEquals(dnames.size(), 2);
		}

	public void testAddDoctor() {
		HospitalDetails details1=new HospitalDetails("Delhi", "Vigyasaa");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
		Doctor doctor=new Doctor(832,"Ramesh",4000,alldetails);
		List<Doctor>allDoctors1=impl.getAllDoctors();
		impl.addDoctor(doctor);
		List<Doctor>allDoctors2=impl.getAllDoctors();
		assertNotSame(allDoctors1.size(),allDoctors2.size());
	}
	
	public void testDeleteDoctor() {
		HospitalDetails details1=new HospitalDetails("Pune", "Layman");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
		@SuppressWarnings("unused")
		Doctor doctor=new Doctor(32,"Ronny",3000,alldetails);		
		int size=impl.getAllDoctors().size();
		impl.deleteDoctor(32);
		int size2=impl.getAllDoctors().size();
		assertNotSame(size2,size-1);	
		}

	public void testUpdateDoctor() {
		HospitalDetails details1=new HospitalDetails("Hyderbad", "Fortis");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
		Doctor doctor=new Doctor(13,"Jaya",3400,alldetails);		
		impl.addDoctor(doctor);
		Doctor p2=new Doctor(1,"Neha",2300,alldetails);		
		impl.updateDoctor(p2);
		assertNotSame(p2, doctor);
		}

	public void testIsDoctorExists() {
		boolean p=impl.isDoctorExists(319);
		assertEquals(false, p);
		HospitalDetails details1=new HospitalDetails("Hyderbad", "Fortis");
		Set<HospitalDetails> alldetails=new HashSet<HospitalDetails>();
    	alldetails.add(details1);
		Doctor doctor=new Doctor(319,"Vaishya",38000,alldetails);		
		impl.addDoctor(doctor);
		boolean p2=impl.isDoctorExists(319);
		assertEquals(true, p2);
		}

	public void testSearchByName() {
		fail("Not yet implemented");
	}

}
