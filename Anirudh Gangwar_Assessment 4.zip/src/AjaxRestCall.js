import React, { Component } from 'react';
import './App.css'
import axios from 'axios'

class App extends Component {
    constructor() {
        super()
        this.state = {
            name : '',
            followers:''
        }
        this.handleClick = this.handleClick.bind(this)
        this.handleChange = this.handleChange.bind(this)
    }
    handleChange(event){
      
        this.setState({
            name : event.target.value
        })
    }
    handleClick() {
        console.log("handleClick Called")
        axios.get('https://api.github.com/users/'+this.state.name)
            .then(response => this.setState({followers: response.data.followers}))
    }
    render() {
        return (
            <div className='btn'>
                Enter username: <input type="text" name="name" onChange={this.handleChange}></input>
                <button className='button' onClick={this.handleClick}>Click Me</button>
                <p>{this.state.followers}</p>
            </div>
        )
    }
}
export default App
