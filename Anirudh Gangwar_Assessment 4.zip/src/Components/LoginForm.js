import React, { Component } from 'react';

class LoginForm extends Component {
    constructor(props){
        super(props);
        this.state={ value: ' ',msg:' '};
        this.handleChange=this.handleChange.bind(this);
        this.takeInputData=this.takeInputData.bind(this);
    }
    handleChange(ourData){
        this.setState({ value: ourData.target.value});
    }
    takeInputData(ourData){
        // alert('A name was submitted: '+this.state.value);
        this.setState({
            msg:'Welcome '+this.state.value
        })
        ourData.preventDefault();
    }
    render() {
        return (
           <form onSubmit={this.takeInputData} className="form-group">
               <div className="col-md-8">
                   Name:
                   <input type="text" value={this.state.value} className= "form-control" onChange={this.handleChange}/>
                   <input type="submit" value="Submit"/>
               </div>
               {this.state.msg}
           </form>
        );
    }
}

export default LoginForm;