import React, { Component } from 'react';
import PropTypes from 'prop-types';

class LifeCycleDemo extends Component {
    constructor(props) {
        super(props);
        this.state={
            name:"Sherlock"
        };
        this.change=this.change.bind(this);
    }
    componentWillMount() {
        console.log("componentWillMount called")
    }

    componentDidMount() {
        console.log("componentDidMount called")
    }

    componentWillReceiveProps(nextProps) {
        console.log("componentWillRecieveProps called")

    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log("shouldComponentUpdate called")
        return true
    }

    componentWillUpdate(nextProps, nextState) {
        console.log("componentWillUpdate called")
    }

    componentDidUpdate(prevProps, prevState) {
        console.log("componentDidUpdate called")
    }

    componentWillUnmount() {
        console.log("componentWillUnMount called")
    }

    change(){
        this.setState({
            name:this.state.name="Gangwar"
        })
    }
    change2=()=>{
        this.setState({
            name:this.state.name="Jimmy"
        })
    }
    render() {
        return (
            <div>
                <h1>Hello {this.state.name}</h1>
                <button onClick={this.change.bind(this)}>BindGo</button>
                <button onClick={()=> this.change()}>ArrowFunctionGo</button>
                <button onClick={this.change}>GoBindingInClassCons</button>
                <button onClick={this.change2}>ClassArrowBinding</button>
            </div>
        )
    }
}

export default LifeCycleDemo;