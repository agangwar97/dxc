import React from 'react'

export default function Message(){
    return <h2>Hello Anirudh</h2>
}