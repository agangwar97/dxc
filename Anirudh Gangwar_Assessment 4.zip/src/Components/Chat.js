import React from 'react'

const Chat=()=>{
    function display(){
        console.log("Display called");
    }
    return (
        <div>
            <button onClick={display}>Display</button>
        </div>
    );
};

export default Chat;