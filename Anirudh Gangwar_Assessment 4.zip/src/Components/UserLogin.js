import React, { Component } from 'react';

class UserLogin extends Component {
    constructor(){
        super()
        this.state=({
            validUser:true,
            textOfButton:'Login',
            loginCount:0,
            loggedinCount:0
        })
        this.toggleButton=this.toggleButton.bind(this)
    }
    toggleButton(){
        if(this.state.validUser==true)
        {
            this.setState({
                validUser:false,
                textOfButton:'LoggedIn',
                loggedinCount:this.state.loggedinCount+=1
            })
        }
        else{
            this.setState({
                validUser:true,
                textOfButton:'Login',
                loginCount:this.state.loginCount+=1
            })
        }
    }
    render() {
        // if(this.state.validUser)
        //     return <div><h1><button onClick={this.toggleButton}>{this.state.textOfButton}</button></h1></div>
        // else
        //     return <div><h1><button onClick={this.toggleButton}>{this.state.textOfButton}</button></h1></div>
        return this.state.validUser ?
        <h1><button onClick={this.toggleButton}>{this.state.textOfButton}</button><h2>loginCount:{this.state.loginCount}</h2></h1>
        :
        <h1><button onClick={this.toggleButton}>{this.state.textOfButton}</button><h2>loggedinCount:{this.state.loggedinCount}</h2></h1>
    }
}

export default UserLogin;