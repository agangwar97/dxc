import React, { Component } from 'react';

class Demo extends Component {
    render() {
        const{uname}=this.props
        return (
            <div>
                <h1>Your name is: {uname}</h1>
            </div>
        );
    }
}

export default Demo;