import React, { Component } from 'react'

class VisitorCount extends Component {
    constructor(props) {
        super(props)

        this.state = ( {
                 numberOfUsers: 0
        })
    }
    increment(){
            // this.setState({
            //     numberOfUsers: this.state.numberOfUsers + 1
            // }, () => { console.log("### async clicking of the button: "+this.state.numberOfUsers)})
            // console.log("After clicking button "+this.state.numberOfUsers)
            this.setState(prevState => ({ 
                numberOfUsers:prevState.numberOfUsers+1
            }),()=>{console.log("### sync clicking of button:"+this.state.numberOfUsers)})
           
            console.log("### async clicking of the button: "+this.state.numberOfUsers)
            }
            incrementThreeTimes(){
                this.increment()
                this.increment()
                this.increment()
            }
    render() {
        console.log("Render method called")
        return (
            <div>
                Number of Visitor : { this.state.numberOfUsers}<br/>
                <button onClick={()=>this.incrementThreeTimes()}>Go</button>
            </div>
        );
    }
}

export default VisitorCount
