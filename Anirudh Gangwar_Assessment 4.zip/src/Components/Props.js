import React, { Component } from 'react';

class Props extends Component {
    render() {
        const {name,designation}=this.props
        return (
            <div>
                <h1>Your name is {name} and designation is {designation}</h1>
            </div>
        );
    }
}

export default Props;