import React from 'react'
import './Unlike.css'

const Unlike = (props) => {
return React.createElement
("div", { id:"myUnlikeDiv1", className:"myDiv100"}, React.createElement("h1",null,"Hello DXC"));
}
export default Unlike