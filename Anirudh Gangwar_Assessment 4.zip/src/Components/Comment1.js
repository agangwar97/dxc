import React, {Component} from 'react'

export default class Comment1 extends Component
{
render(){
    return <h1>Welcome{this.props.commentsText}</h1>
}
}