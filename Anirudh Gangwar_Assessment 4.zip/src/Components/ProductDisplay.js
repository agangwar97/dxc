import React, { Component } from 'react';

class ProductDisplay extends Component {
    render() {
        const {a,product}=this.props
        return (
            <div>
                <h3>Index: {a}{' '}
                    Product Id:{product.productId}{' '}
                    Product Name: {product.productName}{' '}
                    Quantity on Hand: {product.quantityOnHand}{' '}
                    Price: {product.price}</h3>
            </div>
        );
    }
}

export default ProductDisplay;