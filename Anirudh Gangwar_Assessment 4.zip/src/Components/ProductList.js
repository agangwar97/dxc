import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDisplay from './ProductDisplay';
import ProductDetails from './ProductDetails';

class ProductList extends Component {
    constructor(props)
    {
        super(props)
        
    }
    render() {
        const ProductList=[
            {
                productId:1001,
                productName:'Alienware',
                quantityOnHand:100,
                price:100000
            },
            {
                productId:1002,
                productName:'Bose',
                quantityOnHand:1000,
                price:10000
            },
            {
                productId:1003,
                productName:'XPS',
                quantityOnHand:200,
                price:150000
            }
        ]
        return (
            <div>
            {ProductList.map((product, index) =>
                <Link to={`${this.props.match.url}/`+product.productName}>
                    <ProductDisplay render={({ match }) => match={match}}
                        nn={index}
                        key={index}
                        product={product}
                    ></ProductDisplay>
                </Link>

            )}
            
            <Route path={`${this.props.match.path}/:productName`}
                render={({ match }) => match={match}} 
                component={ProductDetails} />
                </div>
        )
     }
    }   

export default ProductList;