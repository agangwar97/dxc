import React , {Component} from 'react'

class TagPeople extends Component
{
    constructor(){
        super()
        console.log("Tag people cons called")
        this.state = {
            message:"Please subscribe",
            quotes : "Hello"
        }
    }
    subscribeMe(){
        this.setState({
            message:"Congrats you have subscribed successfully",
            quotes: "How are you today"
        })
    }
    render(){
        console.log("Tag people render called")
        return <div>
            <h1>Tag {this.props.friendName} Now</h1>
            <h1>
                Message is: { this.state.message}<br/>
                Quote is: { this.state.quotes}<br/>
                <button onClick={() => this.subscribeMe()}>Subscribe</button>
            </h1>
            </div>
    }
}
export default TagPeople