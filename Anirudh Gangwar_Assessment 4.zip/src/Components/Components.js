import React, { Component } from 'react';
import PropTypes from 'prop-types';

class Components extends Component {
    constructor(props) {
        super(props);
        this.state=({
            commentsText:this.props.commentsText
        })
        console.log("1. cons called")
    }
    componentWillMount() {
        console.log("2. componentWillMount called")
        this.state=({
            commentsText:"Let's go for a movie"
        })
    }
    componentDidMount() {
        console.log("4. componentDidMount called")
        this.setState({
            commentsText:"Let's have dinner"
        })
    }

    render() {
        console.log("3.render called")
        return (
            <div>
                <h1>Welcome {this.state.commentsText}</h1>
            </div>
        );
    }
}

Component.propTypes = {

};

export default Components;