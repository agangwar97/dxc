import React from 'react';
import logo from './logo.svg';
import './App.css';
import Welcome from './Components/Welcome'
import Message from './Components/Message'
import Comment1 from './Components/Comment1'
import Like from './Components/Like'
import Unlike from './Components/Unlike'
import TagPeople from './Components/TagPeople'
import VisitorCount from './Components/VisitorCount'
import Props from './Components/Props'
import Props2 from './Components/Props2'
import Props3 from './Components/Props3'
import Chat from './Components/Chat'
import Components from './Components/Components'
import Clock from './Components/Clock';
import LifeCycleDemo from './Components/LifeCycleDemo';
import UserLogin from './Components/UserLogin';
import ParentComponent from './Components/ParentComponent';
import LoginForm from './Components/LoginForm';
import 'bootstrap/dist/css/bootstrap.css'
import TodoApp from './Components/ToDoApp';
import Edit from './Components/Edit';
import Demo from './Components/Demo';
import LoginValidation from './Components/LoginValidation';
import CompleteFormValidation from './Components/CompleteFormValidation';
import ProductList from './Components/ProductList';
import Comment from './Components/Comment'
import AjaxRestCall from './AjaxRestCall'
function App() {
  return (
    <div className="App">
      {/* <AjaxRestCall></AjaxRestCall> */}
      {/* <Welcome name="Gangwar" place="Bangalore"></Welcome>
      <Welcome name="Dave" place="LA"></Welcome> */}
      {/* <Message></Message> */}
      {/* <Comment1 commentsText=" to Facebook"></Comment1> */}
      {/* <Like></Like> */}
      {/* <Like message="Francais"></Like> */}
      {/* <Unlike></Unlike> */}
      {/* <TagPeople friendName="Jay"></TagPeople> */}
      {/* <VisitorCount></VisitorCount> */}
      {/* <Props name="Anirudh" designation="DEV"></Props> */}
      {/* <Props2 name="John" designation="Analyst"></Props2> */}
      {/* <Props3 name="Jack" designation="SME"></Props3> */}
      {/* <Chat></Chat>  */}
      {/* <Components></Components> */}
      {/* <Clock></Clock> */}
      {/* <LifeCycleDemo></LifeCycleDemo> */}
      {/* <UserLogin></UserLogin> */}
      {/* <ParentComponent></ParentComponent> */}
      {/* <LoginForm></LoginForm> */}
      {/* <TodoApp></TodoApp> */}
      {/* <Edit></Edit> */}
      {/* <Demo uname="Harry"></Demo> */}
      {/* <LoginValidation></LoginValidation> */}
      {/* <CompleteFormValidation></CompleteFormValidation> */}
      {/* <ProductList></ProductList> */}
      {/* <Comment></Comment> */}
    </div>
  );
}
export default App;
