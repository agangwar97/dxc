import React, { Component } from 'react';
import ProductList from '../Components/ProductList';

class Product extends Component {
    render() {
        return (
            <div>
                <h1>Product Details here</h1>
                <ProductList></ProductList>
            </div>
        );
    }
}
export default Product;
