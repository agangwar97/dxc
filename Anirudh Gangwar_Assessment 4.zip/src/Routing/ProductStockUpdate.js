import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import ProductDisplay from '../Components/ProductDisplay';
import ProductDetails from '../Components/ProductDetails';
import './LoginValidation.css';

class ProductStockUpdate extends Component {
    constructor(props) {
        super(props)
        this.state = {
            productId: null,
            quantity: null,
            errors: {
                productId: '',
                quantity: ''
            },
            productList: [
                {
                    productId: 1001,
                    productName: 'Alienware',
                    quantityOnHand: 100,
                    price: 100000
                },
                {
                    productId: 1002,
                    productName: 'Bose',
                    quantityOnHand: 1000,
                    price: 10000
                },
                {
                    productId: 1003,
                    productName: 'XPS',
                    quantityOnHand: 200,
                    price: 150000
                }
            ]
        };
    }
    updateStock = (e) => {
        e.preventDefault()
        let arr = this.state.productList
        let toUpdateProductId = this.refs.productId.value
        let toUpdateQuantityOnHand = this.refs.quantityOnHand.value
        console.log(toUpdateQuantityOnHand)
        let updateProduct
        let updateIndex
        arr.map((product, index) => {
            if (product.productId == toUpdateProductId) {
                updateProduct = this.state.productList[index]
                console.log(updateProduct.quantityOnHand)
                updateIndex=index
            }
        }
        )
        this.updateProductMethod(updateIndex, toUpdateQuantityOnHand)

    }

    updateProductMethod(updateIndex, toUpdateQuantityOnHand) {
        var arr = this.state.productList
        arr[updateIndex].quantityOnHand = toUpdateQuantityOnHand
        this.setState({
            productList: arr
        })
    }

    handleChange = (event) => {
        event.preventDefault();
        const { name, value } = event.target;
        let errors = this.state.errors;

        switch (name) {
            case 'productId':
                errors.productId =
                    value.length < 1
                        ? 'Product Id cannot be empty'
                        : '';
                break;
            case 'quantity':
                errors.quantity =
                    value < 0
                        ? 'Quantity cannot be negative'
                        : '';
                break;
            default:
                break;
        }
        this.setState({
            errors, [name]: value
        })

    }
    render() {
        let productList = this.state.productList
        let errors = this.state.errors
        return (
            <div>
                <form>
                    <h2>
                        Enter Product Id: <input type="number" name="productId" ref="productId" onChange={this.handleChange}></input>
                        {errors.productId.length > 0 &&
                            <span className='error'>{errors.productId}</span>}
                    </h2>
                    <h2>
                        Enter Quantity: <input type="number" name="quantity" ref="quantityOnHand" onChange={this.handleChange}></input>
                        {errors.quantity.length > 0 &&
                            <span className='error'>{errors.quantity}</span>}
                    </h2>
                    <button onClick={(e) => this.updateStock(e)}>Update Stock</button>
                </form>
                {this.state.productList.map((product, index) =>
                    <Link to={`${this.props.match.url}/` + product.productName}>
                        <ProductDisplay render={({ match }) => match = { match }}
                            nn={index}
                            key={index}
                            product={product}
                        ></ProductDisplay>
                    </Link>

                )}
                <Route path={`${this.props.match.path}/:productName`}
                    render={({ match }) => match = { match }}
                    component={ProductDetails} />
            </div>
        );
    }
}

export default ProductStockUpdate;