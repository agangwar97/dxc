var express=require("express")
var fs=require('fs')
var app=express()
app.set('view engine','ejs')

app.get("/about",function(request,response){
    var myReadStream=fs.readFileSync("resources/about.txt","utf8")
    response.render('about',{file:myReadStream})
})

console.log("Server started on port:5001")
app.listen(5001);