package com;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Question3
 */
public class Question3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Question3() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String answer3=request.getParameter("radio");
		HttpSession session=request.getSession();
		session.setAttribute("answer3", answer3);
		int marks=0;
		String correctAnswer1=(String) session.getAttribute("correctAnswer1");
		String correctAnswer2=(String) session.getAttribute("correctAnswer2");
		String correctAnswer3=(String) session.getAttribute("correctAnswer3");
		String answer1=(String) session.getAttribute("answer1");
		String answer2=(String) session.getAttribute("answer2");
		String ans3=(String) session.getAttribute("answer3");
		if(correctAnswer1.equals(answer1)) {
			marks++;
		}
		if(correctAnswer2.equals(answer2)) {
			marks++;
		}
		if(correctAnswer3.equals(ans3)) {
			marks++;
		}
		session.setAttribute("marks", marks);
		 RequestDispatcher view = request.getRequestDispatcher("Result.jsp");
	     view.forward(request, response);	
	}

}
