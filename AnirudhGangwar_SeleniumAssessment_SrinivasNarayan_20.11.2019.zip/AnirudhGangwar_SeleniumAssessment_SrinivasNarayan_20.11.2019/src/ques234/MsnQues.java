package ques234;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class MsnQues {
	SoftAssert st=new SoftAssert();
	public WebDriver driver;
	public String Browser="chrome";
	@Test
	public void testcase1() throws InterruptedException{
		if(Browser.equalsIgnoreCase("chrome")){
			System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
			driver=new ChromeDriver(); //OpenBrowser
		}else if(Browser.equalsIgnoreCase("mozilla")){
			System.setProperty("webdriver.firefox.marionette", "geckodriver.exe");
			 driver=new FirefoxDriver();
		}else if(Browser.equalsIgnoreCase("ie")){
			System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
			 driver=new InternetExplorerDriver();
		}
		driver.get("https://www.msn.com/en-in/"); //open url
		driver.manage().window().maximize(); //maximize browser
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		//clicking on one note
		driver.findElement(By.xpath("//h3[contains(text(),'OneNote')]")).click();
		//getting all the window handles
		Set<String> allids = driver.getWindowHandles();
		Iterator<String> it = allids.iterator();
		String mid=it.next();
		String t1=it.next();
		//Tab window
		driver.switchTo().window(t1);
		//entering the number on one note website
		driver.findElement(By.xpath("//input[@id='i0116']")).sendKeys("1234567890");
		Thread.sleep(3000);
		//closing one note website
		driver.close();
		//switching back to main webpage
		driver.switchTo().window(mid);
		//clicking on skype
		driver.findElement(By.xpath("//h3[contains(text(),'Skype')]")).click();
		Thread.sleep(4000);
		driver.quit();
}
}